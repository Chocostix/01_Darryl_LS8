﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class CalculatorScriprt : MonoBehaviour
{
    public float USD_rate = 0.74f, JPY_rate = 82.78f, RM_rate = 3.08f, EUR_rate = 0.63f, KRW_rate = 881.54f, TWD_rate = 20.73f;

    private float SGDUSD, SGDJPY, SGDRM, SGDEUR, SGDKRW, SGDTWD;

    public Toggle USD, JPY, RM, EUR, KRW, TWD;

    public Text catchy;
    public InputField inputAmount, inputConvertedAmount;


    public void Convert()
    {
         float amount = float.Parse(inputAmount.text);
        
        if (USD.isOn == true)
        {
            SGDUSD = amount * USD_rate;
            inputConvertedAmount.text = "$" + (SGDUSD);
        }

        if (JPY.isOn == true)
        {
            SGDJPY = amount * JPY_rate;
            inputConvertedAmount.text = "$" + (SGDJPY);
        }

        if (RM.isOn == true)
        {
            SGDRM = amount * RM_rate;
            inputConvertedAmount.text = "$" + (SGDRM);
        }

        if (EUR.isOn == true)
        {
            SGDEUR = amount * EUR_rate;
            inputConvertedAmount.text = "$" + (SGDEUR);
        }

        if (KRW.isOn == true)
        {
            SGDKRW = amount * KRW_rate;
            inputConvertedAmount.text = "$" + (SGDKRW);
        }

        if (TWD.isOn == true)
        {
            SGDTWD = amount * TWD_rate;
            inputConvertedAmount.text = "$" + (SGDTWD);
        }

    }

    public void Clear()
    {
        inputAmount.text = "";
        inputConvertedAmount.text = "";
    }
}
