using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.Animation.Tests.EditorTests")]
[assembly: InternalsVisibleTo("Unity.2D.Animation.Tests.RuntimeTests")]
[assembly: InternalsVisibleTo("Unity.2D.Animation.Editor")]
[assembly: InternalsVisibleTo("Unity.2D.PsdImporter.Editor")]
[assembly: InternalsVisibleTo("Unity.2D.Psdimporter.Tests.EditorTests")]